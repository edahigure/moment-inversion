#include"tdmt_invb.h"

float A[6];
fitcheck(ss,gg,W,theta,lambda,delta,Mo,nsta,var,vred)
 struct DATA  *ss;
 struct GREEN *gg;
 int nsta;
 float *W,theta, lambda, delta, Mo, *var, *vred;
   {
   int i,j,Zd,Zg,Np,cnt;
   float Dpower, Dtot, Etmp, E, Etot,VAR,DVAR, WSUM, Az, Mscl;

   Mscl = Mo/1.0e+20;
   WSUM=VAR=DVAR=Dtot=Etot=0.0;
   cnt=0;
   for(i=0; i < nsta; i++)
      {
      Dpower=0.0;
      Etmp  =0.0;
      E     =0.0;
      Zd=ss[i].zz;
      Zg=gg[i].zz;
      Np=ss[i].nn;
      Az=ss[i].azi;
      partl(theta,lambda,delta,Az);
      for(j=0; j < Np; j++)
	 {
	 Etmp = ss[i].t[Zd+j] - Mscl*(A[3]*gg[i].u1[j+Zg] + A[4]*gg[i].u2[j+Zg]);
	 E += Etmp*Etmp;
	 Etmp = ss[i].r[Zd+j] - Mscl*(A[0]*gg[i].u3[j+Zg] + A[1]*gg[i].u4[j+Zg] + A[2]*gg[i].u5[j+Zg]);
	 E += Etmp*Etmp;
	 Etmp = ss[i].z[Zd+j] - Mscl*(A[0]*gg[i].u6[j+Zg] + A[1]*gg[i].u7[j+Zg] + A[2]*gg[i].u8[j+Zg]);
	 E += Etmp*Etmp;
	 Dpower += ss[i].t[Zd+j]*ss[i].t[Zd+j];
	 Dpower += ss[i].r[Zd+j]*ss[i].r[Zd+j];
	 Dpower += ss[i].z[Zd+j]*ss[i].z[Zd+j];
	 cnt++;
	 }
	 WSUM += W[3*cnt-1];
	 Etot += E;
	 VAR += W[3*cnt-1]*E;
	 Dtot += Dpower;
	 DVAR += W[3*cnt-1]*Dpower;
	 E /= Dpower;
	 ss[i].vr = (1.0 - E)*100.0;
         fprintf(stderr,"Station(%d)=%f  %g\n",i,ss[i].vr,Dpower);
      }
     *var = Etot/(3.0*(float)cnt-5.0-1.0);
      fprintf(stderr,"VAR=%g\n",*var);
      Etot /= Dtot;
      *vred = (1.0-Etot)*100.0;
      fprintf(stderr,"VR=%.2f  (UNWEIGHTED)\n",*vred);
      VAR /= WSUM;
      DVAR /= WSUM;
      VAR /= DVAR;
      VAR = (1.0-VAR)*100.0;
      fprintf(stderr,"VR=%.2f  (WEIGHTED)\n",VAR);
      *vred=VAR;


   }/*fitcheck end*/

